# Motion components retained for Dayweft

The landing page imports only these client components from the motion kit:

- `MotionKitProvider`
- `GradientField` and `WordRotate` for the hero
- `SpotlightGrid` and `SpotlightCard` for everyday use cases
- `ConceptStory` and `ConceptScene` for the three-act scroll story
- `NotificationStream`, `TerminalReplay`, and `DocumentAssemble` for the story stages
- `Surface` for the dark TerminalReplay stage

The retained support files are `concept-story.module.css`, `stage-kit.module.css`,
`stage-frame.tsx`, `contrast.ts`, `easing.ts`, and `hooks.ts`.
