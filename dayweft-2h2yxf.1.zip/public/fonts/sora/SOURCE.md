# Sora

Downloaded from Google Fonts (https://fonts.googleapis.com/css2?family=Sora:ital,wght@0,400..700&display=swap).
Check the family license on fonts.google.com before redistributing the files elsewhere.
